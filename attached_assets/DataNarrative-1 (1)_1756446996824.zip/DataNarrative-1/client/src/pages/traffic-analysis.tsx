import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import StorySelector from "@/components/ui/story-selector";
import ViewToggle from "@/components/ui/view-toggle";
import MonthlyTrafficChart from "@/components/charts/monthly-traffic-chart";
import DlUlChart from "@/components/charts/dl-ul-chart";
import DeviceRankingChart from "@/components/charts/device-ranking-chart";
import NetworkComparisonChart from "@/components/charts/network-comparison-chart";
import UsagePatternChart from "@/components/charts/usage-pattern-chart";
import { useState } from "react";
import { formatBytes, calculateGrowth, formatMonthYear } from "@/lib/data-utils";
import type { DashboardData } from "@shared/schema";

const stories = [
  { key: "traffic-trends", label: "Traffic Trends" },
  { key: "application-ranking", label: "Application Rankings" },
  { key: "device-ranking", label: "Device Rankings" },
  { key: "network-comparison", label: "4G vs 5G Analysis" },
  { key: "user-behavior", label: "User Behavior Patterns" },
  { key: "miscellaneous", label: "Miscellaneous Trends" },
];

export default function TrafficAnalysis() {
  const [activeStory, setActiveStory] = useState("traffic-trends");
  const [trafficView, setTrafficView] = useState("absolute");
  const [networkView, setNetworkView] = useState("absolute");

  const { data, isLoading, error } = useQuery<DashboardData>({
    queryKey: ['/api/dashboard'],
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          <Skeleton className="h-16" />
          <Skeleton className="h-96" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Error Loading Data</h1>
          <p className="text-gray-600">Failed to load traffic analysis data. Please try again later.</p>
        </div>
      </div>
    );
  }

  const trafficData = data.trafficData.sort((a, b) => a.year - b.year || a.month - b.month);
  const latestTraffic = trafficData[trafficData.length - 1];
  const previousTraffic = trafficData[trafficData.length - 2];

  const renderStoryContent = () => {
    switch (activeStory) {
      case "traffic-trends":
        return (
          <div className="space-y-8">
            <Card>
              <CardContent className="p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Traffic Growth Trajectory</h2>
                <p className="text-lg text-gray-600 mb-6">
                  July 2025 marks a significant acceleration in network usage with strong month-over-month growth.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-rakuten-green mb-2">
                      +{previousTraffic ? calculateGrowth(latestTraffic.totalTraffic, previousTraffic.totalTraffic).toFixed(2) : '0'}%
                    </div>
                    <div className="text-sm text-gray-600">Monthly Growth</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-rakuten-blue mb-2">
                      {formatBytes(latestTraffic.totalTraffic)}
                    </div>
                    <div className="text-sm text-gray-600">Total Traffic</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-rakuten-pink mb-2">
                      {formatBytes(latestTraffic.totalTraffic / 31)}
                    </div>
                    <div className="text-sm text-gray-600">Daily Average</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-medium text-gray-900">Monthly Traffic Growth</h3>
                    <ViewToggle
                      options={[
                        { key: "absolute", label: "Absolute" },
                        { key: "percentage", label: "% Growth" }
                      ]}
                      value={trafficView}
                      onChange={setTrafficView}
                    />
                  </div>
                  <div className="h-80">
                    <MonthlyTrafficChart 
                      data={data.trafficData}
                      showPercentage={trafficView === "percentage"}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-medium text-gray-900">Downlink vs Uplink Trends</h3>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-rakuten-blue rounded-full"></div>
                        <span className="text-xs text-gray-600">Downlink</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-rakuten-red rounded-full"></div>
                        <span className="text-xs text-gray-600">Uplink</span>
                      </div>
                    </div>
                  </div>
                  <div className="h-80">
                    <DlUlChart data={data.trafficData} />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardContent className="p-8">
                <h3 className="text-xl font-medium text-gray-900 mb-6">Download/Upload Ratio Analysis</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-rakuten-blue/5 rounded-lg p-6">
                    <div className="text-2xl font-bold text-rakuten-blue mb-2">
                      {latestTraffic.dlUlRatio.toFixed(2)}:1
                    </div>
                    <div className="text-sm text-gray-600 mb-2">July DL/UL Ratio</div>
                    <div className="text-xs text-gray-500">Consistent with previous months</div>
                  </div>
                  <div className="bg-rakuten-green/5 rounded-lg p-6">
                    <div className="text-2xl font-bold text-rakuten-green mb-2">
                      {formatBytes(latestTraffic.totalDlVol * 1000)}
                    </div>
                    <div className="text-sm text-gray-600 mb-2">Total Downlink</div>
                    <div className="text-xs text-rakuten-green">
                      {previousTraffic ? `+${calculateGrowth(latestTraffic.totalDlVol, previousTraffic.totalDlVol).toFixed(1)}% growth` : 'No comparison data'}
                    </div>
                  </div>
                  <div className="bg-rakuten-red/5 rounded-lg p-6">
                    <div className="text-2xl font-bold text-rakuten-red mb-2">
                      {formatBytes(latestTraffic.totalUlVol * 1000)}
                    </div>
                    <div className="text-sm text-gray-600 mb-2">Total Uplink</div>
                    <div className="text-xs text-rakuten-red">
                      {previousTraffic ? `+${calculateGrowth(latestTraffic.totalUlVol, previousTraffic.totalUlVol).toFixed(1)}% growth` : 'No comparison data'}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case "application-ranking":
        const julyApps = data.applicationRankings
          .filter(app => app.month === 7 && app.year === 2025)
          .sort((a, b) => a.rank - b.rank)
          .slice(0, 3);

        return (
          <div className="space-y-8">
            <Card>
              <CardContent className="p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Application Performance Rankings</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Streaming applications continue to dominate network usage, with consistent top performers.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  {julyApps.map((app, index) => (
                    <div key={app.rank} className={`bg-opacity-5 rounded-lg p-6 ${
                      index === 0 ? 'bg-rakuten-pink' : 
                      index === 1 ? 'bg-rakuten-blue' : 'bg-rakuten-amber'
                    }`}>
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-semibold text-gray-900">{app.application}</h4>
                        <span className={`px-2 py-1 rounded text-xs text-white ${
                          index === 0 ? 'bg-rakuten-pink' : 
                          index === 1 ? 'bg-rakuten-blue' : 'bg-rakuten-amber'
                        }`}>
                          #{app.rank}
                        </span>
                      </div>
                      <div className={`text-2xl font-bold mb-2 ${
                        index === 0 ? 'text-rakuten-pink' : 
                        index === 1 ? 'text-rakuten-blue' : 'text-rakuten-amber'
                      }`}>
                        {formatBytes(app.monthlyData * 1000)}
                      </div>
                      <div className="text-sm text-gray-600">{app.applicationType}</div>
                    </div>
                  ))}
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Top Applications by Category</h4>
                  <div className="space-y-3">
                    {julyApps.map((app) => (
                      <div key={app.rank} className="flex items-center justify-between py-2 px-4 bg-white rounded-lg">
                        <div className="flex items-center space-x-3">
                          <span className="text-sm font-medium text-gray-600">#{app.rank}</span>
                          <span className="font-medium text-gray-900">{app.application}</span>
                          <span className="text-sm text-gray-500">({app.applicationType})</span>
                        </div>
                        <div className="text-sm font-medium text-gray-900">
                          {formatBytes(app.monthlyData * 1000)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case "device-ranking":
        const julyDevices = data.deviceRankings
          .filter(device => device.month === 7 && device.year === 2025)
          .sort((a, b) => a.rank - b.rank)
          .slice(0, 3);

        return (
          <div className="space-y-8">
            <Card>
              <CardContent className="p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Device Performance Analysis</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Premium smartphones continue to lead data consumption patterns.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  {julyDevices.map((device, index) => (
                    <div key={device.rank} className={`bg-opacity-5 rounded-lg p-6 ${
                      index === 0 ? 'bg-rakuten-pink' : 
                      index === 1 ? 'bg-rakuten-blue' : 'bg-rakuten-amber'
                    }`}>
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-semibold text-gray-900">{device.device.split(' ').slice(0, 2).join(' ')}</h4>
                        <span className={`px-2 py-1 rounded text-xs text-white ${
                          index === 0 ? 'bg-rakuten-pink' : 
                          index === 1 ? 'bg-rakuten-blue' : 'bg-rakuten-amber'
                        }`}>
                          #{device.rank}
                        </span>
                      </div>
                      <div className={`text-2xl font-bold mb-2 ${
                        index === 0 ? 'text-rakuten-pink' : 
                        index === 1 ? 'text-rakuten-blue' : 'text-rakuten-amber'
                      }`}>
                        {formatBytes(device.monthlyData * 1000)}
                      </div>
                      <div className="text-sm text-gray-600">Monthly consumption</div>
                    </div>
                  ))}
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Monthly Device Ranking Trends</h4>
                  <div className="h-80">
                    <DeviceRankingChart data={data.deviceRankings} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case "network-comparison":
        return (
          <div className="space-y-8">
            <Card>
              <CardContent className="p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">4G vs 5G Technology Analysis</h2>
                <p className="text-lg text-gray-600 mb-6">
                  5G adoption continues to grow steadily, showing consistent month-over-month progress.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                  <div className="bg-rakuten-blue/5 rounded-lg p-6">
                    <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
                      <span className="w-4 h-4 bg-rakuten-blue rounded-full mr-2"></span>
                      4G Network Performance
                    </h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Daily Average</span>
                        <span className="font-medium">{formatBytes(latestTraffic.total4gData * 1000)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Market Share</span>
                        <span className="font-medium">
                          {((latestTraffic.total4gData / (latestTraffic.total4gData + latestTraffic.total5gData)) * 100).toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-rakuten-green/5 rounded-lg p-6">
                    <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
                      <span className="w-4 h-4 bg-rakuten-green rounded-full mr-2"></span>
                      5G Network Performance
                    </h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Daily Average</span>
                        <span className="font-medium">{formatBytes(latestTraffic.total5gData * 1000)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Market Share</span>
                        <span className="font-medium">
                          {((latestTraffic.total5gData / (latestTraffic.total4gData + latestTraffic.total5gData)) * 100).toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h4 className="font-semibold text-gray-900">Absolute Traffic Trends</h4>
                      <ViewToggle
                        options={[
                          { key: "absolute", label: "Absolute" },
                          { key: "percentage", label: "Percentage" }
                        ]}
                        value={networkView}
                        onChange={setNetworkView}
                      />
                    </div>
                    <div className="h-64">
                      <NetworkComparisonChart 
                        data={data.trafficData} 
                        type={networkView as "absolute" | "percentage"}
                      />
                    </div>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h4 className="font-semibold text-gray-900">Technology Distribution</h4>
                      <div className="flex items-center space-x-2 text-xs">
                        <div className="w-3 h-3 bg-rakuten-blue rounded-full"></div>
                        <span>4G</span>
                        <div className="w-3 h-3 bg-rakuten-green rounded-full ml-2"></div>
                        <span>5G</span>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900 mb-2">
                          {((latestTraffic.total5gData / (latestTraffic.total4gData + latestTraffic.total5gData)) * 100).toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-600">5G Share in July</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-4">
                        <div 
                          className="bg-rakuten-green h-4 rounded-full transition-all duration-300"
                          style={{
                            width: `${(latestTraffic.total5gData / (latestTraffic.total4gData + latestTraffic.total5gData)) * 100}%`
                          }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case "user-behavior":
        return (
          <div className="space-y-8">
            <Card>
              <CardContent className="p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">User Behavior Patterns</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Analyzing usage patterns across different user segments and time periods.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-rakuten-amber/5 rounded-lg p-6">
                    <h4 className="font-semibold text-gray-900 mb-3">Holiday vs Working Days</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Holiday Average</span>
                        <span className="font-medium text-rakuten-amber">{formatBytes(latestTraffic.holidayTraffic * 1000)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Working Day Average</span>
                        <span className="font-medium">{formatBytes(latestTraffic.workingDayTraffic * 1000)}</span>
                      </div>
                      <div className="text-sm text-rakuten-green">
                        +{((latestTraffic.holidayTraffic / latestTraffic.workingDayTraffic - 1) * 100).toFixed(1)}% holiday boost
                      </div>
                    </div>
                  </div>
                  <div className="bg-rakuten-blue/5 rounded-lg p-6">
                    <h4 className="font-semibold text-gray-900 mb-3">B2B vs B2C</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">B2C Traffic</span>
                        <span className="font-medium text-rakuten-blue">{formatBytes(latestTraffic.b2cTraffic * 1000)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">B2B Traffic</span>
                        <span className="font-medium">{formatBytes(latestTraffic.b2bTraffic * 1000)}</span>
                      </div>
                      <div className="text-sm text-rakuten-green">Consumer-driven growth</div>
                    </div>
                  </div>
                  <div className="bg-rakuten-green/5 rounded-lg p-6">
                    <h4 className="font-semibold text-gray-900 mb-3">Roaming Traffic</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">KDDI Roaming</span>
                        <span className="font-medium text-rakuten-green">{formatBytes(latestTraffic.kddiRoaming * 1000)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">IR Roaming</span>
                        <span className="font-medium">{formatBytes(latestTraffic.irRoaming * 1000)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Usage Pattern Distribution</h4>
                  <div className="h-80">
                    <UsagePatternChart data={data.trafficData} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case "miscellaneous":
        return (
          <div className="space-y-8">
            <Card>
              <CardContent className="p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Miscellaneous Network Trends</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Additional insights into network infrastructure and emerging usage patterns.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <div className="bg-rakuten-blue/5 rounded-lg p-4">
                    <h5 className="font-medium text-gray-900 mb-2">CPE Devices</h5>
                    <div className="text-xl font-bold text-rakuten-blue">{formatBytes(latestTraffic.cpeAndOthers * 1000)}</div>
                    <div className="text-xs text-gray-500">Daily average</div>
                  </div>
                  <div className="bg-rakuten-green/5 rounded-lg p-4">
                    <h5 className="font-medium text-gray-900 mb-2">Repeaters</h5>
                    <div className="text-xl font-bold text-rakuten-green">{formatBytes(latestTraffic.repeater * 1000)}</div>
                    <div className="text-xs text-gray-500">Daily average</div>
                  </div>
                  <div className="bg-rakuten-amber/5 rounded-lg p-4">
                    <h5 className="font-medium text-gray-900 mb-2">DL/UL Efficiency</h5>
                    <div className="text-xl font-bold text-rakuten-amber">{latestTraffic.dlUlRatio.toFixed(1)}:1</div>
                    <div className="text-xs text-gray-500">Optimal ratio</div>
                  </div>
                  <div className="bg-rakuten-pink/5 rounded-lg p-4">
                    <h5 className="font-medium text-gray-900 mb-2">Total Growth</h5>
                    <div className="text-xl font-bold text-rakuten-pink">
                      +{previousTraffic ? calculateGrowth(latestTraffic.totalTraffic, previousTraffic.totalTraffic).toFixed(1) : '0'}%
                    </div>
                    <div className="text-xs text-gray-500">Monthly increase</div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-rakuten-pink/5 to-rakuten-blue/5 rounded-lg p-8">
                  <h4 className="font-semibold text-gray-900 mb-6 flex items-center">
                    <span className="w-5 h-5 bg-rakuten-amber rounded-full mr-2 flex items-center justify-center">
                      <span className="w-2 h-2 bg-white rounded-full"></span>
                    </span>
                    Strategic Recommendations
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h5 className="font-medium text-gray-900 mb-3">Network Expansion</h5>
                      <ul className="space-y-2 text-sm text-gray-600">
                        <li className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-rakuten-green rounded-full mt-2 flex-shrink-0"></div>
                          <span>Accelerate 5G deployment in high-traffic areas</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-rakuten-blue rounded-full mt-2 flex-shrink-0"></div>
                          <span>Optimize 4G capacity during peak usage periods</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-rakuten-amber rounded-full mt-2 flex-shrink-0"></div>
                          <span>Enhance holiday weekend infrastructure planning</span>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h5 className="font-medium text-gray-900 mb-3">User Experience</h5>
                      <ul className="space-y-2 text-sm text-gray-600">
                        <li className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-rakuten-pink rounded-full mt-2 flex-shrink-0"></div>
                          <span>Target streaming-optimized plans for growth</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-rakuten-red rounded-full mt-2 flex-shrink-0"></div>
                          <span>Develop premium device partnerships</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-rakuten-green rounded-full mt-2 flex-shrink-0"></div>
                          <span>Introduce 5G-specific service tiers</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Monthly Traffic Analysis</h1>
        <StorySelector 
          stories={stories}
          activeStory={activeStory}
          onStoryChange={setActiveStory}
        />
      </div>

      {renderStoryContent()}
    </div>
  );
}
