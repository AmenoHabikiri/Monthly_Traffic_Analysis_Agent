export interface CSVParseOptions {
  delimiter?: string;
  skipHeaders?: boolean;
  trimValues?: boolean;
}

export class CSVParser {
  private static parseCSVLine(line: string, delimiter: string = ','): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === delimiter && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result;
  }

  static parse(csvContent: string, options: CSVParseOptions = {}): string[][] {
    const {
      delimiter = ',',
      skipHeaders = false,
      trimValues = true
    } = options;

    const lines = csvContent.trim().split('\n');
    const result: string[][] = [];
    
    const startIndex = skipHeaders ? 1 : 0;
    
    for (let i = startIndex; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line) {
        let values = this.parseCSVLine(line, delimiter);
        
        if (trimValues) {
          values = values.map(value => value.trim());
        }
        
        result.push(values);
      }
    }
    
    return result;
  }

  static parseToObjects<T>(
    csvContent: string, 
    headers: string[], 
    options: CSVParseOptions = {}
  ): T[] {
    const rows = this.parse(csvContent, { ...options, skipHeaders: true });
    
    return rows.map(row => {
      const obj: any = {};
      headers.forEach((header, index) => {
        obj[header] = row[index] || '';
      });
      return obj as T;
    });
  }

  static getHeaders(csvContent: string, delimiter: string = ','): string[] {
    const lines = csvContent.trim().split('\n');
    if (lines.length === 0) return [];
    
    return this.parseCSVLine(lines[0], delimiter);
  }

  static validateCSV(csvContent: string, expectedColumns?: number): boolean {
    try {
      const lines = csvContent.trim().split('\n');
      if (lines.length === 0) return false;
      
      const headers = this.parseCSVLine(lines[0]);
      
      if (expectedColumns && headers.length !== expectedColumns) {
        return false;
      }
      
      // Check if all rows have the same number of columns as headers
      for (let i = 1; i < lines.length; i++) {
        const row = this.parseCSVLine(lines[i]);
        if (row.length !== headers.length) {
          console.warn(`Row ${i + 1} has ${row.length} columns, expected ${headers.length}`);
        }
      }
      
      return true;
    } catch (error) {
      console.error('CSV validation error:', error);
      return false;
    }
  }

  static convertToNumeric(value: string): number | string {
    const trimmed = value.trim();
    
    // Handle empty values
    if (!trimmed) return 0;
    
    // Handle quoted numbers
    const unquoted = trimmed.replace(/^"(.*)"$/, '$1');
    
    // Try to parse as number
    const num = parseFloat(unquoted);
    
    // Return number if valid, otherwise return original string
    return !isNaN(num) && isFinite(num) ? num : trimmed;
  }

  static extractMonthlyData(
    csvContent: string,
    monthColumns: { [month: number]: number },
    options: CSVParseOptions = {}
  ): { [month: number]: any[] } {
    const rows = this.parse(csvContent, { ...options, skipHeaders: true });
    const result: { [month: number]: any[] } = {};
    
    Object.keys(monthColumns).forEach(month => {
      result[parseInt(month)] = [];
    });
    
    rows.forEach((row, rowIndex) => {
      Object.entries(monthColumns).forEach(([month, columnIndex]) => {
        const value = row[columnIndex];
        if (value && value.trim()) {
          result[parseInt(month)].push({
            rowIndex,
            value: this.convertToNumeric(value),
            originalRow: row
          });
        }
      });
    });
    
    return result;
  }

  static mergeCSVData(datasets: { name: string; data: string[][] }[]): any[] {
    const merged: any[] = [];
    
    datasets.forEach(dataset => {
      dataset.data.forEach((row, index) => {
        if (!merged[index]) {
          merged[index] = { rowIndex: index };
        }
        
        row.forEach((value, colIndex) => {
          merged[index][`${dataset.name}_col_${colIndex}`] = this.convertToNumeric(value);
        });
      });
    });
    
    return merged;
  }
}

// Utility functions for common CSV operations
export const csvUtils = {
  /**
   * Parse traffic data CSV with specific format
   */
  parseTrafficData: (csvContent: string) => {
    return CSVParser.parseToObjects(csvContent, [
      'year', 'factor', 'month_01', 'month_02', 'month_03', 'month_04',
      'month_05', 'month_06', 'month_07', 'month_08', 'month_09',
      'month_10', 'month_11', 'month_12'
    ]);
  },

  /**
   * Parse application ranking CSV
   */
  parseApplicationData: (csvContent: string) => {
    const headers = CSVParser.getHeaders(csvContent);
    return CSVParser.parseToObjects(csvContent, headers);
  },

  /**
   * Parse device ranking CSV
   */
  parseDeviceData: (csvContent: string) => {
    const headers = CSVParser.getHeaders(csvContent);
    return CSVParser.parseToObjects(csvContent, headers);
  },

  /**
   * Parse calculated metrics CSV
   */
  parseMetricsData: (csvContent: string) => {
    return CSVParser.parseToObjects(csvContent, [
      'year', 'month', 'number_of_days', 'total_traffic',
      'total_normalized_traffic', 'delta', 'delta_percentage'
    ]);
  },

  /**
   * Clean and validate numeric values
   */
  cleanNumericValue: (value: any): number => {
    if (typeof value === 'number') return value;
    if (typeof value === 'string') {
      const cleaned = value.replace(/[",\s]/g, '');
      const num = parseFloat(cleaned);
      return isNaN(num) ? 0 : num;
    }
    return 0;
  },

  /**
   * Group data by time period
   */
  groupByMonth: (data: any[], yearField: string = 'year', monthField: string = 'month') => {
    const grouped: { [key: string]: any[] } = {};
    
    data.forEach(item => {
      const key = `${item[yearField]}-${item[monthField]}`;
      if (!grouped[key]) {
        grouped[key] = [];
      }
      grouped[key].push(item);
    });
    
    return grouped;
  }
};

export default CSVParser;
