import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { RAKUTEN_COLORS, formatBytes, formatMonthYear } from "@/lib/data-utils";
import type { TrafficData } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface DlUlChartProps {
  data: TrafficData[];
}

export default function DlUlChart({ data }: DlUlChartProps) {
  const sortedData = [...data].sort((a, b) => a.year - b.year || a.month - b.month);

  const chartData = {
    labels: sortedData.map(d => formatMonthYear(d.year, d.month)),
    datasets: [
      {
        label: 'Downlink',
        data: sortedData.map(d => d.totalDlVol), // Data is already in GB
        borderColor: RAKUTEN_COLORS.blue,
        backgroundColor: `${RAKUTEN_COLORS.blue}1A`,
        tension: 0.4,
      },
      {
        label: 'Uplink',
        data: sortedData.map(d => d.totalUlVol), // Data is already in GB
        borderColor: RAKUTEN_COLORS.red,
        backgroundColor: `${RAKUTEN_COLORS.red}1A`,
        tension: 0.4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `${context.dataset.label}: ${formatBytes(context.parsed.y)}`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        grid: {
          color: '#f3f4f6',
        },
        ticks: {
          callback: (value: any) => formatBytes(value),
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  return <Line data={chartData} options={options} />;
}
