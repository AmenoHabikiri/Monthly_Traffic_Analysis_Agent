export function formatBytes(gbValue: number, decimals: number = 2): string {
  if (gbValue === 0) return '0 GB';

  const k = 1000;
  const dm = decimals < 0 ? 0 : decimals;
  
  // Input is in GB, convert to appropriate unit
  if (gbValue >= 1000) {
    return (gbValue / k).toFixed(dm) + ' TB';
  }
  
  return gbValue.toFixed(dm) + ' GB';
}

export function formatPercentage(value: number, decimals: number = 1): string {
  return `${value.toFixed(decimals)}%`;
}

export function calculateGrowth(current: number, previous: number): number {
  if (previous === 0) return 0;
  return ((current - previous) / previous) * 100;
}

export function getMonthName(month: number): string {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return months[month - 1] || 'Unknown';
}

export function getMonthShortName(month: number): string {
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  return months[month - 1] || 'Unknown';
}

export function formatMonthYear(year: number, month: number): string {
  return `${getMonthName(month)} ${year}`;
}

export const RAKUTEN_COLORS = {
  pink: '#FF3399',
  red: '#C00000',
  blue: '#0070C0',
  yellow: '#FFC000',
  green: '#00B050',
  amber: '#CC9900',
  gray: '#A6A6A6',
} as const;
