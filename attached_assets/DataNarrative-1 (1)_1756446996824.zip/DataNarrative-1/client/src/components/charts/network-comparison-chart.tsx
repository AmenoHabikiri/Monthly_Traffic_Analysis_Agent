import { Bar, Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { RAKUTEN_COLORS, formatBytes, formatMonthYear } from "@/lib/data-utils";
import type { TrafficData } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface NetworkComparisonChartProps {
  data: TrafficData[];
  type: "absolute" | "percentage";
}

export default function NetworkComparisonChart({ data, type }: NetworkComparisonChartProps) {
  const sortedData = [...data].sort((a, b) => a.year - b.year || a.month - b.month);

  if (type === "absolute") {
    const chartData = {
      labels: sortedData.map(d => formatMonthYear(d.year, d.month)),
      datasets: [
        {
          label: '4G',
          data: sortedData.map(d => d.total4gData), // Data is already in GB
          backgroundColor: RAKUTEN_COLORS.blue,
        },
        {
          label: '5G',
          data: sortedData.map(d => d.total5gData), // Data is already in GB
          backgroundColor: RAKUTEN_COLORS.green,
        },
      ],
    };

    const options = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false,
        },
        tooltip: {
          callbacks: {
            label: (context: any) => {
              return `${context.dataset.label}: ${formatBytes(context.parsed.y)}`;
            },
          },
        },
      },
      scales: {
        x: {
          stacked: true,
          grid: {
            display: false,
          },
        },
        y: {
          stacked: true,
          grid: {
            color: '#f3f4f6',
          },
          ticks: {
            callback: (value: any) => formatBytes(value),
          },
        },
      },
    };

    return <Bar data={chartData} options={options} />;
  } else {
    const chartData = {
      labels: sortedData.map(d => formatMonthYear(d.year, d.month)),
      datasets: [
        {
          label: '4G Share (%)',
          data: sortedData.map(d => {
            const total = d.total4gData + d.total5gData;
            return total > 0 ? (d.total4gData / total) * 100 : 0;
          }),
          borderColor: RAKUTEN_COLORS.blue,
          backgroundColor: `${RAKUTEN_COLORS.blue}1A`,
          tension: 0.4,
          fill: true,
        },
        {
          label: '5G Share (%)',
          data: sortedData.map(d => {
            const total = d.total4gData + d.total5gData;
            return total > 0 ? (d.total5gData / total) * 100 : 0;
          }),
          borderColor: RAKUTEN_COLORS.green,
          backgroundColor: `${RAKUTEN_COLORS.green}1A`,
          tension: 0.4,
          fill: true,
        },
      ],
    };

    const options = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false,
        },
        tooltip: {
          callbacks: {
            label: (context: any) => {
              return `${context.dataset.label}: ${context.parsed.y.toFixed(1)}%`;
            },
          },
        },
      },
      scales: {
        y: {
          min: 0,
          max: 100,
          grid: {
            color: '#f3f4f6',
          },
          ticks: {
            callback: (value: any) => `${value}%`,
          },
        },
        x: {
          grid: {
            display: false,
          },
        },
      },
    };

    return <Line data={chartData} options={options} />;
  }
}
