import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { RAKUTEN_COLORS, formatBytes, formatMonthYear } from "@/lib/data-utils";
import type { TrafficData } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface MonthlyTrafficChartProps {
  data: TrafficData[];
  showPercentage?: boolean;
}

export default function MonthlyTrafficChart({ data, showPercentage = false }: MonthlyTrafficChartProps) {
  const sortedData = [...data].sort((a, b) => a.year - b.year || a.month - b.month);
  
  const chartData = {
    labels: sortedData.map(d => formatMonthYear(d.year, d.month)),
    datasets: [
      {
        label: showPercentage ? 'Growth %' : 'Total Traffic',
        data: showPercentage 
          ? sortedData.map((d, i) => {
              if (i === 0) return 0;
              const prev = sortedData[i - 1];
              return ((d.totalTraffic - prev.totalTraffic) / prev.totalTraffic) * 100;
            })
          : sortedData.map(d => d.totalTraffic), // Data is already in GB
        backgroundColor: RAKUTEN_COLORS.pink,
        borderRadius: 8,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            if (showPercentage) {
              return `Growth: ${context.parsed.y.toFixed(2)}%`;
            } else {
              return `Traffic: ${formatBytes(context.parsed.y)}`;
            }
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: !showPercentage,
        grid: {
          color: '#f3f4f6',
        },
        ticks: {
          callback: (value: any) => {
            if (showPercentage) {
              return `${value}%`;
            } else {
              return formatBytes(value);
            }
          },
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  return <Bar data={chartData} options={options} />;
}
