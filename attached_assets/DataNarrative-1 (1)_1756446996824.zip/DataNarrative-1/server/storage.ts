import fs from 'fs';
import path from 'path';
import type { 
  TrafficData, 
  ApplicationRanking, 
  DeviceRanking, 
  CalculatedMetrics, 
  DashboardData 
} from "@shared/schema";

export interface IStorage {
  getDashboardData(): Promise<DashboardData>;
  getTrafficData(): Promise<TrafficData[]>;
  getApplicationRankings(): Promise<ApplicationRanking[]>;
  getDeviceRankings(): Promise<DeviceRanking[]>;
  getCalculatedMetrics(): Promise<CalculatedMetrics[]>;
}

export class MemStorage implements IStorage {
  private dashboardData: DashboardData | null = null;

  constructor() {
    this.loadDataFromCSV();
  }

  private async loadDataFromCSV() {
    try {
      // Load traffic data
      const trafficData = await this.parseTrafficCSV();
      const applicationRankings = await this.parseApplicationCSV();
      const deviceRankings = await this.parseDeviceCSV();
      const calculatedMetrics = await this.parseCalculatedMetricsCSV();

      this.dashboardData = {
        trafficData,
        applicationRankings,
        deviceRankings,
        calculatedMetrics,
      };
    } catch (error) {
      console.error('Error loading CSV data:', error);
      this.dashboardData = {
        trafficData: [],
        applicationRankings: [],
        deviceRankings: [],
        calculatedMetrics: [],
      };
    }
  }

  private async parseTrafficCSV(): Promise<TrafficData[]> {
    const csvPath = path.join(process.cwd(), 'attached_assets', '_WITH_daily_classified_data_AS_SELECT_untethered_vol_GB_tethered_202508201054_1755667113535.csv');
    const dlUlPath = path.join(process.cwd(), 'attached_assets', '_SELECT_CAST_year_AS_Int32_AS_agg_year_Use_Int32_for_ClickHouse__202508201053_1755667113534.csv');
    
    const csvContent = fs.readFileSync(csvPath, 'utf-8');
    const dlUlContent = fs.readFileSync(dlUlPath, 'utf-8');
    
    const lines = csvContent.trim().split('\n').slice(1); // Skip header
    const dlUlLines = dlUlContent.trim().split('\n').slice(1);
    
    const trafficData: TrafficData[] = [];
    
    // Parse DL/UL data
    const dlUlMap = new Map();
    dlUlLines.forEach(line => {
      const values = this.parseCSVLine(line);
      if (values.length >= 6) {
        const year = parseInt(values[0]);
        const month = parseInt(values[1]);
        dlUlMap.set(`${year}-${month}`, {
          totalDlVol: parseFloat(values[2]),
          totalUlVol: parseFloat(values[3]),
          totalTraffic: parseFloat(values[4]),
          dlUlRatio: parseFloat(values[5]),
        });
      }
    });

    // Parse main traffic data
    const monthlyData = new Map();
    lines.forEach(line => {
      const values = this.parseCSVLine(line);
      if (values.length >= 13) {
        const year = parseInt(values[0]);
        const factor = values[1];
        
        // Process data for months 5, 6, 7 (columns 5, 6, 7)
        [5, 6, 7].forEach((monthIndex, idx) => {
          const month = monthIndex;
          const dataValue = parseFloat(values[monthIndex + 1]) || 0;
          const key = `${year}-${month}`;
          
          if (!monthlyData.has(key)) {
            monthlyData.set(key, { year, month });
          }
          
          const entry = monthlyData.get(key);
          
          switch (factor) {
            case 'Working Day':
              entry.workingDayTraffic = dataValue;
              break;
            case 'Holiday':
              entry.holidayTraffic = dataValue;
              break;
            case 'total_4g_data_daily':
              entry.total4gData = dataValue;
              break;
            case 'total_5g_data_daily':
              entry.total5gData = dataValue;
              break;
            case 'total_dl_vol_gb_daily':
              entry.totalDlVol = dataValue;
              break;
            case 'total_ul_vol_gb_daily':
              entry.totalUlVol = dataValue;
              break;
            case 'B2B':
              entry.b2bTraffic = dataValue;
              break;
            case 'B2C':
              entry.b2cTraffic = dataValue;
              break;
            case 'KDDI_Roaming':
              entry.kddiRoaming = dataValue;
              break;
            case 'IR_Roaming':
              entry.irRoaming = dataValue;
              break;
            case 'CPE_and_others':
              entry.cpeAndOthers = dataValue;
              break;
            case 'Repeater':
              entry.repeater = dataValue;
              break;
          }
        });
      }
    });

    // Combine data
    monthlyData.forEach((data, key) => {
      const dlUlData = dlUlMap.get(key);
      if (dlUlData) {
        trafficData.push({
          year: data.year,
          month: data.month,
          totalTraffic: dlUlData.totalTraffic,
          totalDlVol: dlUlData.totalDlVol,
          totalUlVol: dlUlData.totalUlVol,
          dlUlRatio: dlUlData.dlUlRatio,
          total4gData: data.total4gData || 0,
          total5gData: data.total5gData || 0,
          workingDayTraffic: data.workingDayTraffic || 0,
          holidayTraffic: data.holidayTraffic || 0,
          b2bTraffic: data.b2bTraffic || 0,
          b2cTraffic: data.b2cTraffic || 0,
          kddiRoaming: data.kddiRoaming || 0,
          irRoaming: data.irRoaming || 0,
          cpeAndOthers: data.cpeAndOthers || 0,
          repeater: data.repeater || 0,
        });
      }
    });

    return trafficData.sort((a, b) => a.year - b.year || a.month - b.month);
  }

  private async parseApplicationCSV(): Promise<ApplicationRanking[]> {
    const csvPath = path.join(process.cwd(), 'attached_assets', '_WITH_MonthlyAggregates_AS_SELECT_year_month_serviceid_monitored_202508201054_1755667113536.csv');
    const csvContent = fs.readFileSync(csvPath, 'utf-8');
    const lines = csvContent.trim().split('\n').slice(1);
    
    const applications: ApplicationRanking[] = [];
    
    lines.forEach(line => {
      const values = this.parseCSVLine(line);
      if (values.length >= 22) {
        const year = parseInt(values[0]);
        const rank = parseInt(values[1]);
        
        // Process months 5, 6, 7 (columns start at index 14 for month 5)
        [5, 6, 7].forEach((month, idx) => {
          const appIndex = 14 + (idx * 3); // Each month has 3 columns: app, type, data
          const application = values[appIndex];
          const applicationType = values[appIndex + 1];
          const monthlyData = parseFloat(values[appIndex + 2]);
          
          if (application && applicationType && !isNaN(monthlyData)) {
            applications.push({
              year,
              month,
              rank,
              application,
              applicationType,
              monthlyData,
            });
          }
        });
      }
    });
    
    return applications.sort((a, b) => a.year - b.year || a.month - b.month || a.rank - b.rank);
  }

  private async parseDeviceCSV(): Promise<DeviceRanking[]> {
    const csvPath = path.join(process.cwd(), 'attached_assets', '_WITH_DeviceMonthlyAggregates_AS_SELECT_device_Format_month_as_a_202508201054_1755667113536.csv');
    const csvContent = fs.readFileSync(csvPath, 'utf-8');
    const lines = csvContent.trim().split('\n').slice(1);
    
    const devices: DeviceRanking[] = [];
    
    lines.forEach(line => {
      const values = this.parseCSVLine(line);
      if (values.length >= 14) {
        const year = parseInt(values[0]);
        const rank = parseInt(values[1]);
        
        // Process months 5, 6, 7 (columns start at index 8 for month 5)
        [5, 6, 7].forEach((month, idx) => {
          const deviceIndex = 8 + (idx * 2); // Each month has 2 columns: device, data
          const device = values[deviceIndex];
          const monthlyData = parseFloat(values[deviceIndex + 1]);
          
          if (device && !isNaN(monthlyData)) {
            devices.push({
              year,
              month,
              rank,
              device,
              monthlyData,
            });
          }
        });
      }
    });
    
    return devices.sort((a, b) => a.year - b.year || a.month - b.month || a.rank - b.rank);
  }

  private async parseCalculatedMetricsCSV(): Promise<CalculatedMetrics[]> {
    const csvPath = path.join(process.cwd(), 'attached_assets', 'CalculatedMetrics_202508201053_1755667113536.csv');
    const csvContent = fs.readFileSync(csvPath, 'utf-8');
    const lines = csvContent.trim().split('\n').slice(1);
    
    const metrics: CalculatedMetrics[] = [];
    
    lines.forEach(line => {
      const values = this.parseCSVLine(line);
      if (values.length >= 7) {
        const year = parseInt(values[0]);
        const month = parseInt(values[1]);
        const numberOfDays = parseInt(values[2]);
        const totalTraffic = parseFloat(values[3]);
        const totalNormalizedTraffic = parseFloat(values[4]);
        const delta = parseFloat(values[5]);
        const deltaPercentage = parseFloat(values[6]) || 0;
        
        if (!isNaN(year) && !isNaN(month)) {
          metrics.push({
            year,
            month,
            numberOfDays,
            totalTraffic,
            totalNormalizedTraffic,
            delta,
            deltaPercentage,
          });
        }
      }
    });
    
    return metrics.sort((a, b) => a.year - b.year || a.month - b.month);
  }

  private parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result;
  }

  async getDashboardData(): Promise<DashboardData> {
    if (!this.dashboardData) {
      await this.loadDataFromCSV();
    }
    return this.dashboardData!;
  }

  async getTrafficData(): Promise<TrafficData[]> {
    const data = await this.getDashboardData();
    return data.trafficData;
  }

  async getApplicationRankings(): Promise<ApplicationRanking[]> {
    const data = await this.getDashboardData();
    return data.applicationRankings;
  }

  async getDeviceRankings(): Promise<DeviceRanking[]> {
    const data = await this.getDashboardData();
    return data.deviceRankings;
  }

  async getCalculatedMetrics(): Promise<CalculatedMetrics[]> {
    const data = await this.getDashboardData();
    return data.calculatedMetrics;
  }
}

export const storage = new MemStorage();
