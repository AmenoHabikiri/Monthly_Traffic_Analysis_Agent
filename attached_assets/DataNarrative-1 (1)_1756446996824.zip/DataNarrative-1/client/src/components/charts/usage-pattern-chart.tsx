import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { RAKUTEN_COLORS, formatBytes } from "@/lib/data-utils";
import type { TrafficData } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface UsagePatternChartProps {
  data: TrafficData[];
}

export default function UsagePatternChart({ data }: UsagePatternChartProps) {
  // Get July 2025 data
  const latestData = data.find(d => d.month === 7 && d.year === 2025);
  
  if (!latestData) {
    return <div className="h-full flex items-center justify-center text-gray-500">No data available</div>;
  }

  const chartData = {
    labels: ['Working Day', 'Holiday', 'B2C', 'B2B', 'KDDI Roaming'],
    datasets: [
      {
        label: 'Daily Traffic',
        data: [
          latestData.workingDayTraffic,
          latestData.holidayTraffic,
          latestData.b2cTraffic,
          latestData.b2bTraffic,
          latestData.kddiRoaming,
        ],
        backgroundColor: [
          RAKUTEN_COLORS.blue,
          RAKUTEN_COLORS.amber,
          RAKUTEN_COLORS.pink,
          RAKUTEN_COLORS.green,
          RAKUTEN_COLORS.red,
        ],
        borderRadius: 8,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `${context.label}: ${formatBytes(context.parsed.y)}`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: '#f3f4f6',
        },
        ticks: {
          callback: (value: any) => formatBytes(value),
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  return <Bar data={chartData} options={options} />;
}
