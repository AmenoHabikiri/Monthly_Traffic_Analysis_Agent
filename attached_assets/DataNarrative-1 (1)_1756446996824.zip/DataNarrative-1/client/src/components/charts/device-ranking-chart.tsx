import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { RAKUTEN_COLORS, formatMonthYear } from "@/lib/data-utils";
import type { DeviceRanking } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface DeviceRankingChartProps {
  data: DeviceRanking[];
}

export default function DeviceRankingChart({ data }: DeviceRankingChartProps) {
  // Get top 5 devices by latest month ranking
  const latestMonth = Math.max(...data.map(d => d.month));
  const topDevices = data
    .filter(d => d.month === latestMonth)
    .sort((a, b) => a.rank - b.rank)
    .slice(0, 5)
    .map(d => d.device);

  const months = [...new Set(data.map(d => d.month))].sort();
  const years = [...new Set(data.map(d => d.year))];
  const year = years[0];

  const chartData = {
    labels: months.map(m => formatMonthYear(year, m)),
    datasets: topDevices.map((device, index) => {
      const deviceData = months.map(month => {
        const record = data.find(d => d.device === device && d.month === month);
        return record ? record.rank : null;
      });

      return {
        label: device,
        data: deviceData,
        borderColor: Object.values(RAKUTEN_COLORS)[index % Object.values(RAKUTEN_COLORS).length],
        tension: 0.4,
      };
    }),
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `${context.dataset.label}: Rank ${context.parsed.y}`;
          },
        },
      },
    },
    scales: {
      y: {
        reverse: true,
        min: 1,
        max: 10,
        grid: {
          color: '#f3f4f6',
        },
        ticks: {
          stepSize: 1,
          callback: (value: any) => `#${value}`,
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  return <Line data={chartData} options={options} />;
}
