import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface KPICardProps {
  title: string;
  value: string;
  subtitle: string;
  description: string;
  iconColor: string;
  icon: React.ReactNode;
  trend?: "up" | "down";
  trendValue?: string;
}

export default function KPICard({
  title,
  value,
  subtitle,
  description,
  iconColor,
  icon,
  trend,
  trendValue
}: KPICardProps) {
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center",
              iconColor
            )}>
              {icon}
            </div>
            <h3 className="text-sm font-medium text-gray-600">{title}</h3>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-gray-900">{value}</div>
            {trendValue && (
              <div className={cn(
                "text-sm",
                trend === "up" ? "text-rakuten-green" : "text-rakuten-red"
              )}>
                {trendValue}
              </div>
            )}
            {subtitle && (
              <div className="text-sm text-rakuten-green">{subtitle}</div>
            )}
          </div>
        </div>
        <div className="text-sm text-gray-500">
          {description}
        </div>
      </CardContent>
    </Card>
  );
}
