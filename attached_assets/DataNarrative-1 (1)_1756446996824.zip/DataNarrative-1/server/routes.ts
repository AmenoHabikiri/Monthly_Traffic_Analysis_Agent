import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard data endpoint
  app.get("/api/dashboard", async (req, res) => {
    try {
      const data = await storage.getDashboardData();
      res.json(data);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  // Traffic data endpoint
  app.get("/api/traffic", async (req, res) => {
    try {
      const data = await storage.getTrafficData();
      res.json(data);
    } catch (error) {
      console.error("Error fetching traffic data:", error);
      res.status(500).json({ message: "Failed to fetch traffic data" });
    }
  });

  // Application rankings endpoint
  app.get("/api/applications", async (req, res) => {
    try {
      const data = await storage.getApplicationRankings();
      res.json(data);
    } catch (error) {
      console.error("Error fetching application data:", error);
      res.status(500).json({ message: "Failed to fetch application data" });
    }
  });

  // Device rankings endpoint
  app.get("/api/devices", async (req, res) => {
    try {
      const data = await storage.getDeviceRankings();
      res.json(data);
    } catch (error) {
      console.error("Error fetching device data:", error);
      res.status(500).json({ message: "Failed to fetch device data" });
    }
  });

  // Calculated metrics endpoint
  app.get("/api/metrics", async (req, res) => {
    try {
      const data = await storage.getCalculatedMetrics();
      res.json(data);
    } catch (error) {
      console.error("Error fetching metrics data:", error);
      res.status(500).json({ message: "Failed to fetch metrics data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
