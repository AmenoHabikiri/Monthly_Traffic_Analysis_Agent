import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface StorySelectorProps {
  stories: { key: string; label: string }[];
  activeStory: string;
  onStoryChange: (story: string) => void;
}

export default function StorySelector({ stories, activeStory, onStoryChange }: StorySelectorProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
      <div className="flex flex-wrap gap-2">
        {stories.map((story) => (
          <Button
            key={story.key}
            onClick={() => onStoryChange(story.key)}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
              activeStory === story.key
                ? "bg-rakuten-pink text-white hover:bg-rakuten-pink/90"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            )}
          >
            {story.label}
          </Button>
        ))}
      </div>
    </div>
  );
}
