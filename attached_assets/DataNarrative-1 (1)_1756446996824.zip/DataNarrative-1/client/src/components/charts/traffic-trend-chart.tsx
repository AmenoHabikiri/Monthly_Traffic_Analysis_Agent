import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { RAKUTEN_COLORS, formatBytes, formatMonthYear } from "@/lib/data-utils";
import type { CalculatedMetrics } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface TrafficTrendChartProps {
  data: CalculatedMetrics[];
  showPercentage?: boolean;
}

export default function TrafficTrendChart({ data, showPercentage = false }: TrafficTrendChartProps) {
  const chartData = {
    labels: data.map(d => formatMonthYear(d.year, d.month)),
    datasets: [
      {
        label: showPercentage ? 'Growth %' : 'Total Traffic',
        data: showPercentage 
          ? data.map(d => d.deltaPercentage || 0)
          : data.map(d => d.totalTraffic), // Data is already in GB
        borderColor: RAKUTEN_COLORS.pink,
        backgroundColor: `${RAKUTEN_COLORS.pink}1A`,
        tension: 0.4,
        fill: true,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            if (showPercentage) {
              return `Growth: ${context.parsed.y.toFixed(2)}%`;
            } else {
              return `Traffic: ${formatBytes(context.parsed.y)}`;
            }
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: !showPercentage,
        grid: {
          color: '#f3f4f6',
        },
        ticks: {
          callback: (value: any) => {
            if (showPercentage) {
              return `${value}%`;
            } else {
              return formatBytes(value);
            }
          },
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  return <Line data={chartData} options={options} />;
}
