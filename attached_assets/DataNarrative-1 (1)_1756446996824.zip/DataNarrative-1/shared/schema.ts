import { z } from "zod";

// Traffic data schema
export const trafficDataSchema = z.object({
  year: z.number(),
  month: z.number(),
  totalTraffic: z.number(),
  totalDlVol: z.number(),
  totalUlVol: z.number(),
  dlUlRatio: z.number(),
  total4gData: z.number(),
  total5gData: z.number(),
  workingDayTraffic: z.number(),
  holidayTraffic: z.number(),
  b2bTraffic: z.number(),
  b2cTraffic: z.number(),
  kddiRoaming: z.number(),
  irRoaming: z.number(),
  cpeAndOthers: z.number(),
  repeater: z.number(),
});

// Application ranking schema
export const applicationRankingSchema = z.object({
  rank: z.number(),
  application: z.string(),
  applicationType: z.string(),
  monthlyData: z.number(),
  month: z.number(),
  year: z.number(),
});

// Device ranking schema
export const deviceRankingSchema = z.object({
  rank: z.number(),
  device: z.string(),
  monthlyData: z.number(),
  month: z.number(),
  year: z.number(),
});

// Calculated metrics schema
export const calculatedMetricsSchema = z.object({
  year: z.number(),
  month: z.number(),
  numberOfDays: z.number(),
  totalTraffic: z.number(),
  totalNormalizedTraffic: z.number(),
  delta: z.number(),
  deltaPercentage: z.number(),
});

export type TrafficData = z.infer<typeof trafficDataSchema>;
export type ApplicationRanking = z.infer<typeof applicationRankingSchema>;
export type DeviceRanking = z.infer<typeof deviceRankingSchema>;
export type CalculatedMetrics = z.infer<typeof calculatedMetricsSchema>;

// API response schemas
export const dashboardDataSchema = z.object({
  trafficData: z.array(trafficDataSchema),
  applicationRankings: z.array(applicationRankingSchema),
  deviceRankings: z.array(deviceRankingSchema),
  calculatedMetrics: z.array(calculatedMetricsSchema),
});

export type DashboardData = z.infer<typeof dashboardDataSchema>;
