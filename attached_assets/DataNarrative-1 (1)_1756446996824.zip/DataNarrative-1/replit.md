# Overview

This is a full-stack analytics dashboard application for Rakuten Mobile that visualizes network traffic data through interactive charts and storyboards. The application displays telecommunications data including application rankings, device rankings, traffic patterns, and network technology comparisons (4G vs 5G). It's designed as an executive dashboard similar to data visualization platforms like pudding.cool, featuring monthly traffic analysis with the ability to switch between different data stories and view types (absolute values vs percentages).

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Components**: Shadcn/ui component library built on top of Radix UI primitives
- **Styling**: Tailwind CSS with custom color scheme matching Rakuten Mobile branding
- **Charts**: Chart.js for data visualization with interactive charts
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation

## Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Structure**: RESTful API endpoints for dashboard data, traffic data, application rankings, and device rankings
- **Data Storage**: In-memory storage with CSV file parsing for data ingestion
- **Middleware**: Custom logging middleware for API request monitoring

## Data Schema
- **Validation**: Zod schemas for type-safe data validation across shared types
- **Data Models**: Structured schemas for traffic data, application rankings, device rankings, and calculated metrics
- **Shared Types**: Common type definitions between frontend and backend using a shared schema file

## Chart Configuration
- **Visualization Library**: Chart.js with React wrapper for interactive charts
- **Chart Types**: Bar charts, line charts, doughnut charts for different data representations
- **Color Scheme**: Custom Rakuten Mobile color palette (pink, red, blue, yellow, green, amber, gray)
- **Interactivity**: Toggle between absolute values and percentage views for comparative analysis

## Development Setup
- **Build System**: Vite for fast development and optimized production builds
- **TypeScript**: Strict type checking with path mapping for clean imports
- **CSS Processing**: PostCSS with Tailwind CSS and Autoprefixer
- **Development Tools**: Hot module replacement, runtime error overlay, and Replit integration plugins

# External Dependencies

## Database and Storage
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Database Provider**: Neon Database serverless PostgreSQL
- **Schema Management**: Drizzle Kit for database migrations and schema management

## UI and Styling
- **Component Library**: Radix UI primitives for accessible, unstyled components
- **CSS Framework**: Tailwind CSS for utility-first styling
- **Icon Library**: Lucide React for consistent iconography
- **Date Utilities**: date-fns for date formatting and manipulation

## Data Visualization
- **Charting**: Chart.js for creating interactive charts and graphs
- **State Management**: TanStack React Query for server state and caching

## Development and Build Tools
- **Bundler**: Vite for development server and production builds
- **Runtime**: tsx for TypeScript execution in development
- **Build Tool**: esbuild for server-side bundling
- **Deployment**: Configured for Node.js production environment

## Session and Storage
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **File Processing**: Built-in Node.js modules for CSV parsing and file system operations