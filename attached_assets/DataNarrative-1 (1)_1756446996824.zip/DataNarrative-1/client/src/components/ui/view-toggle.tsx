import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ViewToggleProps {
  options: { key: string; label: string }[];
  value: string;
  onChange: (value: string) => void;
}

export default function ViewToggle({ options, value, onChange }: ViewToggleProps) {
  return (
    <div className="flex items-center space-x-2">
      {options.map((option) => (
        <Button
          key={option.key}
          size="sm"
          variant="ghost"
          onClick={() => onChange(option.key)}
          className={cn(
            "px-3 py-1 text-xs font-medium rounded-full transition-colors",
            value === option.key
              ? "bg-rakuten-pink text-white hover:bg-rakuten-pink/90"
              : "bg-gray-200 text-gray-600 hover:bg-gray-300"
          )}
        >
          {option.label}
        </Button>
      ))}
    </div>
  );
}
