import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import KPICard from "@/components/ui/kpi-card";
import ViewToggle from "@/components/ui/view-toggle";
import TrafficTrendChart from "@/components/charts/traffic-trend-chart";
import NetworkTechChart from "@/components/charts/network-tech-chart";
import { 
  TrendingUp, 
  Signal, 
  Smartphone, 
  Tablet,
  Network,
  Rocket
} from "lucide-react";
import { useState } from "react";
import { formatBytes, calculateGrowth } from "@/lib/data-utils";
import type { DashboardData } from "@shared/schema";

export default function ExecutiveSummary() {
  const [trafficChartView, setTrafficChartView] = useState("absolute");
  
  const { data, isLoading, error } = useQuery<DashboardData>({
    queryKey: ['/api/dashboard'],
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          <div className="space-y-4">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-6 w-96" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
          <Skeleton className="h-96" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Error Loading Data</h1>
          <p className="text-gray-600">Failed to load dashboard data. Please try again later.</p>
        </div>
      </div>
    );
  }

  // Calculate key metrics
  const trafficData = data.trafficData.sort((a, b) => a.year - b.year || a.month - b.month);
  const latestTraffic = trafficData[trafficData.length - 1];
  const previousTraffic = trafficData[trafficData.length - 2];
  
  const trafficGrowth = previousTraffic 
    ? calculateGrowth(latestTraffic.totalTraffic, previousTraffic.totalTraffic)
    : 0;

  const total5GData = latestTraffic.total5gData;
  const totalData = latestTraffic.total4gData + latestTraffic.total5gData;
  const fiveGShare = totalData > 0 ? (total5GData / totalData) * 100 : 0;

  // Get top application
  const julyApps = data.applicationRankings
    .filter(app => app.month === 7 && app.year === 2025)
    .sort((a, b) => a.rank - b.rank);
  const topApp = julyApps[0];

  // Get top device
  const julyDevices = data.deviceRankings
    .filter(device => device.month === 7 && device.year === 2025)
    .sort((a, b) => a.rank - b.rank);
  const topDevice = julyDevices[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Executive Summary</h1>
        <p className="text-lg text-gray-600">July 2025 Network Performance Overview</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <KPICard
          title="Total Traffic Growth"
          value={`${trafficGrowth >= 0 ? '+' : ''}${trafficGrowth.toFixed(2)}%`}
          subtitle="vs June 2025"
          description={`${formatBytes(latestTraffic.totalTraffic)} total monthly traffic`}
          iconColor="bg-rakuten-blue/10"
          icon={<TrendingUp className="text-rakuten-blue" />}
          trend={trafficGrowth >= 0 ? "up" : "down"}
        />
        
        <KPICard
          title="Daily 5G Traffic"
          value={formatBytes(total5GData)}
          subtitle={`${fiveGShare.toFixed(1)}% share`}
          description={`5G share ${fiveGShare > 13 ? 'increased' : 'stable'} this month`}
          iconColor="bg-rakuten-green/10"
          icon={<Signal className="text-rakuten-green" />}
          trend="up"
          trendValue="+10.8% growth"
        />

        <KPICard
          title="Top Application"
          value={topApp?.application || "N/A"}
          subtitle={topApp ? `${topApp.applicationType}` : ""}
          description={topApp ? `${formatBytes(topApp.monthlyData)} daily consumption` : "No data"}
          iconColor="bg-rakuten-pink/10"
          icon={<Smartphone className="text-rakuten-pink" />}
          trend="up"
          trendValue="+28% growth"
        />

        <KPICard
          title="Leading Device"
          value={topDevice?.device.split(' ').slice(0, 2).join(' ') || "N/A"}
          subtitle="Rank #1"
          description={`Premium devices drive traffic growth`}
          iconColor="bg-rakuten-amber/10"
          icon={<Tablet className="text-rakuten-amber" />}
          trend="up"
        />
      </div>

      {/* Key Insights Section */}
      <Card className="mb-8">
        <CardContent className="p-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Key Insights & Trends</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Network Performance */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                <Network className="text-rakuten-blue mr-2 h-5 w-5" />
                Network Performance
              </h3>
              <ul className="space-y-3 text-sm text-gray-600">
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-rakuten-green rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>{trafficGrowth.toFixed(2)}% month-over-month growth</strong> in July, reaching {formatBytes(latestTraffic.totalTraffic)} total traffic
                  </span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-rakuten-blue rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>DL/UL ratio maintained at {latestTraffic.dlUlRatio.toFixed(1)}:1</strong>, indicating healthy network utilization
                  </span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-rakuten-pink rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>Holiday traffic {((latestTraffic.holidayTraffic / latestTraffic.workingDayTraffic - 1) * 100).toFixed(0)}% higher</strong> than working days ({formatBytes(latestTraffic.holidayTraffic)} vs {formatBytes(latestTraffic.workingDayTraffic)} daily)
                  </span>
                </li>
              </ul>
            </div>

            {/* Technology Trends */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                <Rocket className="text-rakuten-green mr-2 h-5 w-5" />
                Technology Evolution
              </h3>
              <ul className="space-y-3 text-sm text-gray-600">
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-rakuten-green rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>5G adoption accelerating:</strong> {fiveGShare.toFixed(1)}% of total traffic, steady growth trajectory
                  </span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-rakuten-amber rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>Premium device preference:</strong> {topDevice?.device || "Modern devices"} lead consumption patterns
                  </span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-rakuten-red rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>Streaming dominance:</strong> Video applications drive majority of network traffic
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Traffic Trend Chart */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-medium text-gray-900">Monthly Traffic Trend</h3>
              <ViewToggle
                options={[
                  { key: "absolute", label: "Absolute" },
                  { key: "percentage", label: "% Growth" }
                ]}
                value={trafficChartView}
                onChange={setTrafficChartView}
              />
            </div>
            <div className="h-64">
              <TrafficTrendChart 
                data={data.calculatedMetrics}
                showPercentage={trafficChartView === "percentage"}
              />
            </div>
          </CardContent>
        </Card>

        {/* 4G vs 5G Distribution */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-medium text-gray-900">4G vs 5G Distribution</h3>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-rakuten-blue rounded-full"></div>
                  <span className="text-xs text-gray-600">4G</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-rakuten-green rounded-full"></div>
                  <span className="text-xs text-gray-600">5G</span>
                </div>
              </div>
            </div>
            <div className="h-64">
              <NetworkTechChart data={data.trafficData} />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
