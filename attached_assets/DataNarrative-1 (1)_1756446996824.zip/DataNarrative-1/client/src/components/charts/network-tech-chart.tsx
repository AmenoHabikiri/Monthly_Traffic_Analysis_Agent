import { Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";
import { RAKUTEN_COLORS } from "@/lib/data-utils";
import type { TrafficData } from "@shared/schema";

ChartJS.register(ArcElement, Tooltip, Legend);

interface NetworkTechChartProps {
  data: TrafficData[];
}

export default function NetworkTechChart({ data }: NetworkTechChartProps) {
  // Get latest data (July 2025)
  const latestData = data.find(d => d.month === 7 && d.year === 2025);
  
  if (!latestData) {
    return <div className="h-full flex items-center justify-center text-gray-500">No data available</div>;
  }

  const total = latestData.total4gData + latestData.total5gData;
  const percentage4G = (latestData.total4gData / total) * 100;
  const percentage5G = (latestData.total5gData / total) * 100;

  const chartData = {
    labels: ['4G', '5G'],
    datasets: [
      {
        data: [percentage4G, percentage5G],
        backgroundColor: [RAKUTEN_COLORS.blue, RAKUTEN_COLORS.green],
        borderWidth: 0,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `${context.label}: ${context.parsed.toFixed(1)}%`;
          },
        },
      },
    },
  };

  return <Doughnut data={chartData} options={options} />;
}
